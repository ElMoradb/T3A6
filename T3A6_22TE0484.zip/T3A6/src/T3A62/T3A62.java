
package T3A62;


    public class T3A62 {
    private double nomina;
    
    public T3A62 (){}

    public T3A62(double nomina) {
        this.nomina = nomina;
    }

    public double getNomina() {
        return nomina;
    }

    public void setNomina(double nomina) {
        this.nomina = nomina;
    }

    @Override
    public String toString() {
        return "su nomina por las empresas seria " + nomina;
    }
    
    
}

